// Lowe 1 8 24 Chapter 1 in class activity 1
public class SongLyrics {

	public static void main(String[] args) {
		System.out.println("Hello");
		System.out.println("I've waited here for you");
		System.out.println("Everlong");
		

	}

}
