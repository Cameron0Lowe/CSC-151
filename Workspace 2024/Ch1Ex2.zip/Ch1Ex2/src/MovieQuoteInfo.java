// Lowe 1 8 24 Chapter 1 in class activity 2
public class MovieQuoteInfo {

	public static void main(String[] args) {
		System.out.println("Now, I'm about to do to you what Limp Bizkit did to music in the late 90s");
		System.out.println("Quote from Deadpool");
		System.out.println("From the 2016 Deadpool movie");

	}

}
