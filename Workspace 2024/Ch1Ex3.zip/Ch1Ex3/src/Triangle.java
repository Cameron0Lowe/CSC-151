
public class Triangle {

	public static void main(String[] args) {
		System.out.println("       T");
		System.out.println("      TTT");
		System.out.println("     TTTTT");
		System.out.println("   TTTTTTTTT");
		System.out.println("  TTTTTTTTTTT");
		System.out.println(" TTTTTTTTTTTTT");
		System.out.println("TTTTTTTTTTTTTTT");

	}

}
